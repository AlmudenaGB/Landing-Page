CREATE DATABASE prestamos;
USE prestamos;

create table libro (
	ISBN varchar(10) primary key,
    titulo varchar(50) not null,
    autor varchar(50) not null
);

create table usuario (
	id int primary key auto_increment,
    nombre varchar(50) not null,
    email varchar(80) not null
);

create table prestamo (
	id_prestamo int primary key auto_increment,
	id_usuario int not null,
    ISBN varchar(10) not null,
    fecha_prestamo date not null,
    fecha_devolucion date,
    dias_penalizacion int,
    nivel_sancion varchar(10),
    mensaje varchar(500),
    foreign key (id_usuario) references usuario(id),
    foreign key (ISBN) references libro (ISBN)
);

create table sancionados(
	id_sancionado int primary key auto_increment,
	codigo_usuario int not null,
    fecha_prestamo date not null, 
    dias_sancion int not null,
    mensaje varchar(500) not null,
	foreign key (codigo_usuario) references usuario(id)
);

DELIMITER $$
CREATE PROCEDURE INSERTAR_LIBRO(p_ISBN varchar(10), p_titulo varchar(50), p_autor varchar(50))
BEGIN
	INSERT INTO libro (ISBN, titulo, autor) VALUES (p_ISBN, p_titulo, p_autor);
END; $$

DELIMITER $$
CREATE PROCEDURE INSERTAR_USUARIO(p_nombre varchar(50), p_email varchar(80)) 
BEGIN
	INSERT INTO usuario(nombre, email) VALUES (p_nombre, p_email);
END; $$

DELIMITER $$
CREATE PROCEDURE INSERTAR_PRESTAMO(p_usuario INTEGER, p_ISBN VARCHAR(10), p_fecha_prestamo DATE) 
BEGIN
	INSERT INTO prestamo(id_usuario, ISBN, fecha_prestamo) VALUES (p_usuario, p_ISBN, p_fecha_prestamo);
END; $$

DELIMITER $$
CREATE FUNCTION SANCION_USUARIO(p_fecha_prestamo DATE) 
RETURNS VARCHAR(10)
DETERMINISTIC
BEGIN
	DECLARE v_resultado VARCHAR(10);
    DECLARE v_dias INTEGER;
    
    -- Calcular los dias entre la fecha actual y la de prestamo
    SET v_dias = DATEDIFF(CURRENT_TIMESTAMP, p_fecha_prestamo);
    
    -- Dependiendo de los dias devolvemos un resultado
    IF (v_dias <= 7) THEN
		SET v_resultado = 'ACTIVO';
	ELSEIF (v_dias > 7 AND v_dias < 12) THEN
		SET v_resultado = 'GRAVE';
	ELSEIF (v_dias > 12) THEN 
		SET v_resultado = 'MUY GRAVE';
	END IF;
    
	RETURN v_resultado;
END; $$

DELIMITER $$
CREATE FUNCTION MENSAJE_SANCION(p_nombre varchar(50), p_fecha_prestamo date, p_codigo INTEGER)
RETURNS VARCHAR(500)
DETERMINISTIC
BEGIN
	DECLARE mensaje VARCHAR(500);
    DECLARE dias INTEGER;
    DECLARE sancion VARCHAR(10);
    
	-- Calcular los dias entre la fecha actual y la de prestamo
    SET dias = DATEDIFF(CURRENT_TIMESTAMP, p_fecha_prestamo);
    
    -- Calcular la sancion según la fecha de prestamo
    SET sancion := SANCION_USUARIO(p_fecha_prestamo);
    
    -- Montar el mensaje
    IF (sancion = 'GRAVE' OR sancion = 'MUY GRAVE') THEN
		SET mensaje = CONCAT("Estimado usuario ", p_nombre, ", el pasado dia ", p_fecha_prestamo, 
				" realizó un prestamo en nuestra biblioteca con código ", p_codigo, 
				" y ha superado la fecha de entrega prevista en ", dias, " dias, por lo que le corresponde una sanción ",
				sancion);
	ELSE
		SET mensaje = "";
	END IF;
    
    RETURN mensaje;
    
END; $$


DELIMITER $$
CREATE PROCEDURE GESTOR() 
BEGIN
	DECLARE contador INTEGER;
    DECLARE registros INTEGER;
    DECLARE v_id_usuario INTEGER;
    DECLARE v_dias INTEGER;
    DECLARE v_sancion VARCHAR(10);
    DECLARE v_mensaje VARCHAR(500);
    DECLARE v_nombre VARCHAR(50);
    DECLARE v_fecha_prestamo DATE;
    
    -- Guarda el maximo id de prestamo que tiene la tabla prestamo
    SET registros = (SELECT MAX(id_prestamo) FROM prestamo);
    
    SET contador = 1;
    
    -- Bucle que vaya contando desde 1 hasta el maximo id de prestamo
    WHILE (contador <= registros) DO
		
        -- Obtener la fecha de prestamo para cada prestamo segun el contador
        SET v_fecha_prestamo = (SELECT fecha_prestamo FROM prestamo WHERE id_prestamo = contador);
        
        -- Calcular la sanción para cada prestamo según la fecha de prestamo
		SET v_sancion = SANCION_USUARIO(v_fecha_prestamo);
        
        -- Si el nivel de sancion es distinto de ACTIVO
        IF v_sancion = 'GRAVE' OR v_sancion = 'MUY GRAVE' THEN
        
			-- Obtener el id del usuario del prestamo actual
            SET v_id_usuario = (SELECT id_usuario FROM prestamo WHERE id_prestamo = contador);
        
			-- Obtener el nombre del usuario a partir del id de usuario
			SET v_nombre = (SELECT nombre FROM usuario where id = v_id_usuario);
        
			-- Calcular el mensaje de la sancion
            SET v_mensaje = MENSAJE_SANCION(v_nombre, v_fecha_prestamo, contador);
            
            -- Calcular los dias entre la fecha actual y la de prestamo
			SET v_dias = DATEDIFF(CURRENT_TIMESTAMP, v_fecha_prestamo);
            
            -- Actualizo la tabla prestamo, añadiendo el mensaje y la sanción
            -- para el prestamos actual (contador)
            UPDATE prestamo
            SET nivel_sancion = v_sancion, mensaje = v_mensaje, dias_penalizacion = v_dias, fecha_devolucion = current_date()
            WHERE id_prestamo = contador;

            -- Insertar en la tabla sancionados este usuario
            INSERT INTO sancionados(codigo_usuario, fecha_prestamo, dias_sancion, mensaje)
            VALUES (v_id_usuario, v_fecha_prestamo, v_dias, v_mensaje);
        END IF;
    
	
        SET contador = contador + 1;
    
    END WHILE;
END; $$

-- LIBROS
CALL INSERTAR_LIBRO("12345678", "Mis mejores recetas", "Karlos Arguiñano");
CALL INSERTAR_LIBRO("87654321", "La sombra del viento", "Carlos Ruiz Zafón");
CALL INSERTAR_LIBRO("11223344", "Mundial 2010", "Vicente del Bosque");

-- USUARIOS
CALL INSERTAR_USUARIO("Manuel Lopez", "manulopez@gmail.com"); 
CALL INSERTAR_USUARIO("Lucía Sanchez", "lucci@gmail.com");

-- PRESTAMO
CALL INSERTAR_PRESTAMO(1, "12345678", "2025-04-04"); 
CALL INSERTAR_PRESTAMO(2, "11223344", "2025-04-25"); 
CALL INSERTAR_PRESTAMO(2, "87654321", "2025-04-30"); 

-- Llamar al gestor
CALL GESTOR();

-- comprobar los prestamos
SELECT * FROM prestamo;