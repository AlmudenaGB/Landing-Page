package principales;

import java.util.List;
import java.util.Scanner;

import modelo.dao.ClienteDao;
import modelo.dao.ClienteDaoImplMy8Jdbc;
import modelo.javabeans.Cliente;

public class GestionClientes {

	private static ClienteDao cdao;
	static {
		cdao = new ClienteDaoImplMy8Jdbc();
	}
	
	public static void main(String[] args) {
		
		//alta();
		//buscarUno();
		//mostrarTodos();
		//eliminar();
		//exportar();
		importar();
	}
	
	public static void alta() {
		//Crear un objeto Cliente
		Cliente cliente = new Cliente("A1234567Y", "Juan", "Vazquez", "Avda Francia, 34", 95000, 20);
		
		//Llamamos al dao para insertarlo
		if (cdao.altaCliente(cliente) == true) {
			System.out.println("Cliente insertado correctamente");
		}
		else {
			System.out.println("Error al insertar el cliente");
		}
	}
	
	public static void buscarUno() {
		
		Cliente cliente = cdao.buscarUnCliente("A11111112");
		
		if (cliente != null) {
			System.out.println("Cliente encontrado");
			System.out.println(cliente);
		}
		else {
			System.out.println("Cliente no encontrado");
		}
	}
	
	public static void mostrarTodos()  {
		List<Cliente> lista = cdao.buscarTodos();
		
		//Recorrer la lista
		for (Cliente cliente: lista) {
			//Usamos el toString para mostrar
			System.out.println(cliente.toString());
		}
	}
	
	public static void eliminar() {
		//Llamamos al dao para borrar
		if (cdao.eliminarCliente("A1234567Y") == true) {
			System.out.println("Cliente eliminado correctamente");
		}
		else {
			System.out.println("Cliente no existe");
		}
	}
	
	public static void exportar() {
		String resultado = cdao.exportar("clientes.txt");
		System.out.println(resultado);
	}

	public static void importar() {
		List<Cliente> lista = cdao.importar("clientes.txt");
		
		//Recorrer la lista
		for (Cliente cliente: lista) {
			//Usamos el toString para mostrar
			System.out.println(cliente.toString());
		}
	}
}
