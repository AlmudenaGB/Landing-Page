package modelo.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionMy8 {
	
	private static Connection conn;
	private String usuario = "root";
	private String password = "admin";
	private String url = "jdbc:mysql://localhost:3306/proyectos_FP_2025";
	
	//Patron Singleton => solamente puede haber una instancia de la conexión
	//Constructor es privado
	private ConexionMy8() {
		try {
			conn = DriverManager.getConnection(url, usuario, password);
			System.out.println("\nCONEXION ESTABLECIDA");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("\nCONEXION NO ESTABLECIDA");
		}
	}
	
	//Metodo que controla que solamente se puede instanciar el constructor una vez
	public static Connection getConnection() {
		//Si la conexion es null => no está instanciada
		if (conn == null) {
			//Crear la conexión
			new ConexionMy8();
		}
		
		//Si está ya instanciada devuelve la instancia que hay
		return conn;
	}
}
