package modelo.dao;

import java.util.List;

import modelo.javabeans.Cliente;

public interface ClienteDao {
	
	//Definimos los metodos que se implementaran en la clase
	public String exportar(String nombreFichero); 
	public List<Cliente> importar(String nombreFichero); 
	public List<Cliente> buscarTodos();
	public Cliente buscarUnCliente(String cif);
	public boolean altaCliente(Cliente cliente);
	public boolean eliminarCliente(String cif);
}
