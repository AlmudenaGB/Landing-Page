package modelo.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import modelo.javabeans.Cliente;

public class ClienteDaoImplMy8Jdbc extends AbsGenericoImplMy8 implements ClienteDao{
	
	public ClienteDaoImplMy8Jdbc() {
	}
	
	@Override
	public List<Cliente> buscarTodos() {
		
		//Lista para devolver los clientes
		List<Cliente> listaCliente = new ArrayList<Cliente>();
		
		//Sentencia a ejecutar para buscar todos los clientes
		sql = "SELECT * FROM clientes";
		
		try {
			//Preparar la consulta sql en la conexión conn para ser ejecutada			
			ps = conn.prepareStatement(sql);
			
			//Ejecutamos la consulta preparada y el resultado que devuelve esa consulta
			//se almacena en un objeto ResultSet
			rs = ps.executeQuery();
			
			//Recorrer el ResultSet con un bucle
			while (rs.next()) {
				//Crear un objeto Cliente con los datos del ResultSet
				Cliente cliente = new Cliente(rs.getString("cif"), rs.getString("nombre"), 
											  rs.getString("apellidos"), rs.getString("domicilio"),
											  rs.getDouble("facturacion_anual"),
											  rs.getInt("numero_empleados"));
				
				//Añadir el cliente a la lista
				listaCliente.add(cliente);
			}
			
			//Cerrar los objetos de la base de datos
			rs.close();
			ps.close();	
		}
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		
		return listaCliente;
	}
	
	@Override
	public String exportar(String nombreFichero) {
		
		//Variable resultado final
		String resultado = "";

		try {
			
			//Crear un objeto File para comprobar si el fichero existe
			File fich = new File(nombreFichero);

			if (fich.exists() == true) {
			
				//Recuperar lista de clientes de la base de datos
				List<Cliente> listaCliente = buscarTodos();
				
				//Creamos un objeto FileWriter para abrir el fichero para escribir
				//Si ya existe un fichero con el nombre se sobreescribe
				FileWriter fichero = new FileWriter(nombreFichero);
	
				//Creamos un objeto BufferedWriter que es quien escribe en el fichero
				//y le pasamos el objeto FileWriter anterior
				BufferedWriter escritura = new BufferedWriter(fichero);
				
				//Recorrer la lista 
				for (Cliente cliente: listaCliente) {
					
					//Escribo el cliente en el fichero
					escritura.write(cliente.getCif() + "," + cliente.getNombre() + "," + cliente.getApellidos() + 
									"," + cliente.getDomicilio() + "," + cliente.getFacturacion_anual() 
									+ "," + cliente.getNumero_empleados() + "\n");
				}
				
				//Cerrar los objetos del fichero
				escritura.close();
				fichero.close();
				
				resultado = "Clientes bien exportados";
			}
			else {
				//Crear el fichero en disco para la proxima vez
				fich.createNewFile();
				//Guardar el resultado
				resultado = "Fichero no existe";
			}
			
		}
		catch (IOException ex) {
			System.out.println("Error al exportar el fichero");
		}
		
		return resultado;
	}
	
	public String exportarBinario(String nombreFichero) {

		//Resultado final a devolver
		String resultado = "";
		
		try {
			
			//Crear un objeto File para comprobar si el fichero existe
			File fich = new File(nombreFichero);
			
			//Si el fichero existe
			if (fich.exists() == true) {

				//Recuperar lista de clientes de la base de datos
				List<Cliente> listaCliente = buscarTodos();
				//Crear fichero binario
	            FileOutputStream fichero = new FileOutputStream(nombreFichero);
	            //Crear objeto que escribe la lista en el fichero binario pasandole como parametro
	            //el objeto FileOutputStream anterior
	            ObjectOutputStream escritura = new ObjectOutputStream(fichero);
	            //Escribo la lista de golpe en el fichero binario
	            escritura.writeObject(listaCliente);
				
				//Cerrar los objetos del fichero
				escritura.close();
				fichero.close();
				
				resultado = "Clientes bien exportados";
			}
			else {
				//Crear el fichero en disco para la proxima vez
				fich.createNewFile();
				//Guardar el resultado
				resultado = "Fichero no existe";
			}
			
		}
		catch (IOException ex) {
			System.out.println("Error al leer el fichero");
		}
		
		return resultado;
	}

	@Override
	public List<Cliente> importar(String nombreFichero) {
		//Crear una lista de clientes
		List<Cliente> listaCliente = new ArrayList<Cliente>();

		try {
			
			//Crear un objeto File para comprobar si el fichero existe
			File fich = new File(nombreFichero);
			
			//Si el fichero existe
			if (fich.exists() == true) {				
				
				//Crear fichero de texto para leer
	            FileReader fichero = new FileReader(nombreFichero);
	            //Crear objeto que lee la lista del fichero binario pasandole como parametro
	            //el objeto FileInputStream anterior
	            BufferedReader lectura = new BufferedReader(fichero);
	            
	            String linea = "";
	            //Leer el fichero de texto linea por linea
	            while ((linea = lectura.readLine()) != null) {
	            	//Separar los datos por el caracter ','
	            	String[] datos = linea.split(",");
	            	
	            	//Crear un objeto Cliente con los datos del fichero
					Cliente cliente = new Cliente(datos[0], datos[1], datos[2], datos[3],
												  Double.parseDouble(datos[4]),
												  Integer.parseInt(datos[5]));
					
					//Añadir el cliente a la lista
					listaCliente.add(cliente);
	            }
				
				//Cerrar los objetos del fichero
	            lectura.close();
				fichero.close();
			}
		}
		catch (IOException ex) {
			System.out.println("Error al importar el fichero");
		}
		
		return listaCliente;
	}
	
	public List<Cliente> importarBinario(String nombreFichero) {
		
		//Crear una lista de clientes
		List<Cliente> listaCliente = new ArrayList<Cliente>();

		try {
			
			//Crear un objeto File para comprobar si el fichero existe
			File fich = new File(nombreFichero);
			
			//Si el fichero existe
			if (fich.exists() == true) {				
				
				//Crear fichero binario para leer
	            FileInputStream fichero = new FileInputStream(nombreFichero);
	            //Crear objeto que lee la lista del fichero binario pasandole como parametro
	            //el objeto FileInputStream anterior
	            ObjectInputStream lectura = new ObjectInputStream(fichero);
	            //Leo la lista de golpe del fichero binario y la asigno a la lista donde la quiero guardar
	            //como readObject lee un objeto generico, lo tengo que convertir al tipo que quiero leer
	            //usando casting
	            listaCliente = (List<Cliente>) lectura.readObject();
				
				//Cerrar los objetos del fichero
	            lectura.close();
				fichero.close();
			}
		}
		catch (ClassNotFoundException | IOException ex) {
			System.out.println("Error al importar el fichero");
		}
		
		return listaCliente;
	}

	@Override
	public Cliente buscarUnCliente(String cif) {
		//Objeto Cliente para devolver
		Cliente cliente = null;
		
		//Sentencia a ejecutar para buscar un cliente según su cif
		sql = "SELECT * FROM clientes where cif = ?";
		
		try {
			//Preparar la consulta sql en la conexión conn para ser ejecutada			
			ps = conn.prepareStatement(sql);
			
			//Sustituir la ? por el cif del parametro
			ps.setString(1, cif);
			
			//Ejecutamos la consulta preparada y el resultado que devuelve esa consulta
			//se almacena en un objeto ResultSet
			rs = ps.executeQuery();
			
			//Si el ResultSet devuelve un resultado
			if (rs.next()) {
				//Asigno al objeto Cliente los datos del ResultSet
				cliente = new Cliente(rs.getString("cif"), rs.getString("nombre"), 
											  rs.getString("apellidos"), rs.getString("domicilio"),
											  rs.getDouble("facturacion_anual"),
											  rs.getInt("numero_empleados"));
			}
			
			//Cerrar los objetos de la base de datos
			rs.close();
			ps.close();	
		}
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		
		return cliente;
	}

	@Override
	public boolean altaCliente(Cliente cliente) {		
		//Variable booleana para devolver si se ha insertado bien el cliente
		boolean insertado = false;
		
		//Sentencia a ejecutar para insertar un cliente
		sql = "INSERT INTO clientes (cif, nombre, apellidos, domicilio, facturacion_anual, numero_empleados) " +
				"VALUES (?, ?, ?, ?, ?, ?)";
		
		try {
			//Preparar la consulta sql en la conexión conn para ser ejecutada			
			ps = conn.prepareStatement(sql);
			
			//Sustituir cada ? en el mismo orden de los parametros
			ps.setString(1, cliente.getCif());
			ps.setString(2, cliente.getNombre());
			ps.setString(3, cliente.getApellidos());
			ps.setString(4, cliente.getDomicilio());
			ps.setDouble(5, cliente.getFacturacion_anual());
			ps.setInt(6, cliente.getNumero_empleados());
			
			//Ejecutamos la consulta preparada y el resultado que devuelve es
			//el número de filas insertadas
			filas = ps.executeUpdate();
			
			//Si el numero de filas insertadas es 1, se ha insertado correctamente
			if (filas == 1) {
				insertado = true;
			}
			
			//Cerrar los objetos de la base de datos
			ps.close();	
		}
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		
		return insertado;
	}

	@Override
	public boolean eliminarCliente(String cif) {
		//Variable booleana para devolver si se ha insertado bien el cliente
		boolean borrado = false;
		
		//Sentencia a ejecutar para insertar un cliente
		sql = "DELETE FROM clientes WHERE cif = ?";
		
		try {
			//Preparar la consulta sql en la conexión conn para ser ejecutada			
			ps = conn.prepareStatement(sql);
			
			//Sustituir cada ? en el mismo orden de los parametros
			ps.setString(1, cif);

			//Ejecutamos la consulta preparada y el resultado que devuelve es
			//el número de filas eliminadas
			filas = ps.executeUpdate();
			
			//Si el numero de filas elimiandas es 1, se ha borrado correctamente
			if (filas == 1) {
				borrado = true;
			}
			
			//Cerrar los objetos de la base de datos
			ps.close();	
		}
		catch (SQLException ex) {
			ex.printStackTrace();
		}
		
		return borrado;
	}
}
