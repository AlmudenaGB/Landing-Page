package es.empresa.torneo;

public class Main {
    public static void main(String[] args) {
        System.out.println("Bienvenido al torneo!");
    }
}
