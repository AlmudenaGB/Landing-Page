package es.empresa.torneo.modelo;

public class Premio {
    private String trofeo;

    public void asignarPremio(String trofeo){
        this.trofeo = trofeo;
    }
}
